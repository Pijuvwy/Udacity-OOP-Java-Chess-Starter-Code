package com.company;


class Position{
    int row;
    int column;
    // Constructor using row and column values
    Position(int r, int c){
        this.row = r;
        this.column = c;
    }
}